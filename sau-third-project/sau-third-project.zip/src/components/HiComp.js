// functional components Arrow function

import React from "react";

const HiComp = () => {
  return (
    <>
      <br />
      <strong>
        <u>Hi.....</u>
      </strong>
      <hr />
    </>
  );
};

export default HiComp;
