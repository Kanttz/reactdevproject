// functional components

import React from "react";
import HeyComp from "./HeyComp";

function HelloComp() {
  return (
    <>
      <h2>Hello....</h2>
      <br />
      <HeyComp />
    </>
  );
}

export default HelloComp;
