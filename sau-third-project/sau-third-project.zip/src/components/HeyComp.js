import React from "react";
import logo from "./../logo.svg";

class HeyComp extends React.Component {
  render() {
    return (
      <>
        <img src={logo} width="100" alt="Wow" />
      </>
    );
  }
}

export default HeyComp;
