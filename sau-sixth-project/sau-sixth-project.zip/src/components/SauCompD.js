import React from "react";

export const SauCompD = ({ value1 }) => {
  return (
    <>
      <h1>Hi...2023 {value1[0] + value1[1] + value1[2]}</h1>
    </>
  );
};
