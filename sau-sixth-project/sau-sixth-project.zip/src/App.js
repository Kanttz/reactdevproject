// import logo from "./logo.svg";
import "./App.css";
import SauCompE from "./components/SauCompE";
// import SauCompA from "./components/SauCompA";
// import SauCompB from "./components/SauCompB";
// import SauCompC from "./components/SauCompC";
// import { SauCompD } from "./components/SauCompD";

function App() {
  return (
    <>
      <SauCompE />

      {/* <SauCompA info1 ="Wow..." info2="Wee..."/><br/><br/>
      <SauCompB data1={20} data2={30} data13={50}/><br/><br/>
      <SauCompC sau1={{x:20, y:"AAA", z:true}}/><br/><br/>
      <SauCompD value1={[111, 222, 333]}/><br/><br/> */}
    </>
  );
}

export default App;
