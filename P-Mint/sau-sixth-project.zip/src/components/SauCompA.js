import React from "react";

function SauCompA({info1,info2}){
    return(
        <>
        <h1>Hi......2023 {info1} {info2}</h1>
        </>
    );

}
export default SauCompA