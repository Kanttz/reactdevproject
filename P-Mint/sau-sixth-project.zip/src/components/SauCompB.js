import React from "react";
const SauCompB = ({ data1, data2, data3 }) => {
    return (
        <>
            <h1>Hey......2023 {data1 + data2 + data3} </h1>
        </>
    );
}
export default SauCompB