//rfce คีย์ลัด 1
import React, { useState, useEffect } from "react";

function SauCompE() {
  const [stuName, setStuName] = useState("??? ????");
  const [midterm, setMidterm] = useState("0");
  const [final, setFinal] = useState("0");
  const [total, setTotal] = useState("0");
  const [grade, setGrade] = useState("?");

  useEffect(() => {
    calGrade();
  }, [midterm, final]);

  const calGrade = () => {
    const totalScore = parseFloat(midterm) + parseFloat(final);
    if (totalScore >= 80) {
      setGrade("A");
    } else if (totalScore >= 70) {
      setGrade("B");
    } else if (totalScore >= 60) {
      setGrade("C");
    } else if (totalScore >= 50) {
      setGrade("D");
    } else {
      setGrade("F");
    }
  };

  //cpf คีย์ลัด
  const handleChangeofName = (e) => {
    setStuName(e.target.value);
  };
  const handleChangeofMidterm = (e) => {
    if (e.target.value === 0) {
      setMidterm("0");
    } else {
      setMidterm(e.target.value);
    }
  };

  const handleChangeofFinal = (e) => {
    setFinal(e.target.value);
  };

  const handleChangeofTotalScore = (e) => {
    e.preventDefault();
    setTotal(parseFloat(midterm) + parseFloat(final));
    calGrade();
  };

  return (
    <>
      <h1>แสดงผลการเรียน</h1>
      <hr />
      ป้อนชื่อ :{" "}
      <input
        onChange={handleChangeofName}
        type="text"
        placeholder="ชื่อ-สุกล"
      />
      <br />
      <br />
      ป้อนคะแนนกลางภาค :{" "}
      <input
        onChange={handleChangeofMidterm}
        type="number"
        placeholder="0.00"
      />
      <br />
      <br />
      ป้อนคะแนนปลายภาค :{" "}
      <input onChange={handleChangeofFinal} type="number" placeholder="0.00" />
      <br />
      <br />
      <button onClick={handleChangeofTotalScore}>คำนวณ</button>
      &nbsp;&nbsp;
      <button>ยกเลิก</button>
      <hr />
      คุณ : {stuName} <br />
      คะแนนกลางภาค : {midterm} <br />
      คะแนนปลายภาค : {final} <br />
      คะแนนรวม : {total}
      <br />
      เกรดที่ได้ : {grade}
      <br />
    </>
  );
}

export default SauCompE;

//----------------------------------------------------------------------------------------
//คิดว่าเป็นแบบที่ 1 คือ ทำงานแบบ Syn ซึ่งการทำงานจะไม่ถูกต้อง
//setGrade(
//     total > 80 ? "A" :
//     total > 70 ? "B" :
//     total > 60 ? "C" :
//     total > 50 ? "D" :
//     "F"
// )
//----------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------
//----------------------------------------------------------------------------
// rfc คีย์ลัด 2
// import React from 'react'

// export default function SauCompE() {
//   return (
//     <div>SauCompE</div>
//   )
// }

//----------------------------------------------------------------------------

// rafce คีย์ลัด 3
// import React from 'react'

// const SauCompE = () => {
//   return (
//     <div>SauCompE</div>
//   )
// }

// export default SauCompE

//----------------------------------------------------------------------------

//rafc คีย์ลัด 4
// import React from 'react'

// export const SauCompE = () => {
//   return (
//     <div>SauCompE</div>
//   )
// }
