import React from "react";
export default function SauCompC({sau1}) {
    return (
        <>
            <h1>Hum....2023 {sau1.x} {sau1.y} {sau1.z.toString()}</h1>
        </>
    );
}