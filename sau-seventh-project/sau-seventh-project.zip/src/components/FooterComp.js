import React from "react";

const FooterComp = () => {
  return (
    <>
      <hr />
      <h3>Created by ID: 6352410018</h3>
      <h3>SAU 2023</h3>
    </>
  );
};

export default FooterComp;
