import React from 'react'

const HeaderComp = () => {
  return (
    <h1 style={{textAlign:'center'}}>SHAPE AREA</h1>
  )
}

export default HeaderComp